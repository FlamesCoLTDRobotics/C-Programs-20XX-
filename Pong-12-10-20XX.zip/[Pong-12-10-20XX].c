#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define SCREEN_WIDTH 80
#define SCREEN_HEIGHT 24

int main() {
  // Initialize screen buffer
  char screen[SCREEN_HEIGHT][SCREEN_WIDTH];
  for (int y = 0; y < SCREEN_HEIGHT; y++) {
    for (int x = 0; x < SCREEN_WIDTH; x++) {
      screen[y][x] = ' ';
    }
  }

  // Initialize game objects
  int ballX = SCREEN_WIDTH / 2;
  int ballY = SCREEN_HEIGHT / 2;
  int ballDX = 1;
  int ballDY = 1;
  int paddle1Y = SCREEN_HEIGHT / 2;
  int paddle2Y = SCREEN_HEIGHT / 2;

  // Main game loop
  while (true) {
    // Clear screen
    system("clear");

    // Update ball position
    ballX += ballDX;
    ballY += ballDY;

    // Check for ball collisions
    if (ballX == 0) {
      // Ball hit left wall
      ballDX = 1;
    } else if (ballX == SCREEN_WIDTH - 1) {
      // Ball hit right wall
      ballDX = -1;
    } else if (ballY == 0 || ballY == SCREEN_HEIGHT - 1) {
      // Ball hit top or bottom wall
      ballDY *= -1;
    } else if (ballX == 1 && ballY >= paddle1Y && ballY < paddle1Y + 5) {
      // Ball hit left paddle
      ballDX = 1;
    } else if (ballX == SCREEN_WIDTH - 2 && ballY >= paddle2Y && ballY < paddle2Y + 5) {
      // Ball hit right paddle
      ballDX = -1;
    }

    // Update paddle positions
    if (paddle1Y > 0 && paddle1Y < SCREEN_HEIGHT - 5) {
      // Move left paddle up or down based on user input
      if (getchar() == 'w') {
        paddle1Y--;
      } else if (getchar() == 's') {
        paddle1Y++;
      }
    }
    if (paddle2Y > 0 && paddle2Y < SCREEN_HEIGHT - 5) {
      // Move right paddle up or down based on user input
      if (getchar() == 'i') {
        paddle2Y--;
      } else if (getchar() == 'k') {
        paddle2Y++;
      }
    }

    // Update screen buffer
    screen[ballY][ballX] = 'O';
    for (int y = paddle1Y; y < paddle1Y + 5; y++) {
      screen[y][1] = '|';
    }
    for (int y = paddle2Y; y < paddle2Y + 5; y++) {
      screen[y][SCREEN_WIDTH - 2] = '|';
    }

    // Print screen buffer
    for (int y = 0; y < SCREEN_HEIGHT; y++) {
      for (int x = 0; x < SCREEN_WIDTH; x++) {
        printf("%c", screen[y][x]);
      }
      printf("\n");
    }
  }
}
