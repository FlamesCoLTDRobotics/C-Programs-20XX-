#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function to get the filename from a full path
char* get_filename(char* path) {
  char* filename = path + strlen(path);
  while (filename > path && *filename != '/') {
    filename--;
  }
  if (*filename == '/') {
    filename++;
  }
  return filename;
}

int main(int argc, char** argv) {
  if (argc < 2) {
    printf("Usage: %s <source file>\n", argv[0]);
    return 1;
  }

  char* source_file = argv[1];
  char* compiled_file = strdup(get_filename(source_file));
  strcpy(compiled_file + strlen(compiled_file) - 2, "out");

  char* command = malloc(strlen(source_file) + strlen(compiled_file) + 20);
  sprintf(command, "gcc %s -o %s", source_file, compiled_file);

  int result = system(command);
  free(command);
  free(compiled_file);

  if (result != 0) {
    printf("Error compiling %s\n", source_file);
    return 1;
  }

  printf("Successfully compiled %s to %s\n", source_file, compiled_file);
  return 0;
}
