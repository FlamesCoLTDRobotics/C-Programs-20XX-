 #include <stdio.h>

int main(void) {
  printf("\u263A\n");
  return 0;
}
