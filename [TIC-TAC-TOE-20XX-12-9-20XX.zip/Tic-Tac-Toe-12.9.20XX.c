#include<stdio.h>

// Function to get the current player's turn 
int getTurn(int player) 
{ 
	if (player == 1) 
		return 2; 
	else
		return 1; 
} 

// Function to print the game board 
void printBoard(char board[3][3]) 
{ 
	printf("\n\n"); 

	printf(" %c | %c | %c \n", board[0][0], board[0][1], board[0][2]); 
	printf("___|___|___\n"); 
	printf(" %c | %c | %c \n", board[1][0], board[1][1], board[1][2]); 
	printf("___|___|___\n"); 
	printf(" %c | %c | %c \n", board[2][0], board[2][1], board[2][2]); 
	printf("   |   |   \n\n"); 
} 

// Function to get user's input 
int userInput(char board[3][3], int player) 
{ 
	int row, col; 
	char mark; 

	if (player == 1) 
		mark = 'X'; 
	else
		mark = 'O'; 

	while (1) { 
		printf("Player %d - Enter the coordinates (row, col): ", player); 
		scanf("%d %d", &row, &col); 

		// Check if the cell is empty 
		if (row >= 0 && row < 3 && col >= 0 && col < 3 
				&& board[row][col] == ' ') 
			break; 
		else
			printf("Invalid move! Try again.\n"); 
	} 

	board[row][col] = mark; 
} 

// Function to check win 
int win(char board[3][3], int player) 
{ 
	// check for win in rows 
	for (int i=0; i<3; i++) 
		if (board[i][0] == board[i][1] && 
			board[i][1] == board[i][2] && 
			board[i][0] != ' ') 
			return 1; 

	// check for win in columns 
	for (int j=0; j<3; j++) 
		if (board[0][j] == board[1][j] && 
			board[1][j] == board[2][j] && 
			board[0][j] != ' ') 
			return 1; 

	// check for win in diagonal 
	if (board[0][0] == board[1][1] && 
		board[1][1] == board[2][2] && 
		board[0][0] != ' ') 
		return 1; 

	if (board[0][2] == board[1][1] && 
		board[1][1] == board[2][0] && 
		board[0][2] != ' ') 
		return 1; 

	return 0; 
} 

// Function to check draw 
int draw(char board[3][3]) 
{ 
	// Check if a move is remaining 
	for (int i=0; i<3; i++) 
		for (int j=0; j<3; j++) 
			if (board[i][j] == ' ') 
				return 0; 

	// If all cells are filled and there is 
	// no winner, it's a draw 
	printBoard(board); 
	printf("It's a draw!\n"); 
	return 1; 
} 

// Main Function 
int main() 
{ 
	// Initialize the game board 
	char board[3][3] = { 
						{ ' ', ' ', ' ' }, 
						{ ' ', ' ', ' ' }, 
						{ ' ', ' ', ' ' } 
					}; 

	// Declare variables 
	int currplayer = 1, i, winner; 

	printf("\nTic-Tac-Toe\n\n"); 
	printf("Player 1 (X)  -  Player 2 (O)\n\n"); 

	// Print the game board 
	printBoard(board); 

	// Loop until the game is finished 
	for (i = 0; i < 9 && !winner; i++) { 
		userInput(board, currplayer); 

		// Print the game board 
		printBoard(board); 

		// Check if the current player has won 
		winner = win(board, currplayer); 

		// Switch players 
		currplayer = getTurn(currplayer); 
	} 

	if (!winner) 
		draw(board); 
	else
		printf("Player %d has won\n", currplayer); 

	return 0; 
}